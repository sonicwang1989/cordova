var MainCtrl = [
    '$rootScope', '$scope', '$routeParams', '$location', '$window', '$timeout', '$q',
    function ($rootScope, $scope, $routeParams, $location, $window, $timeout, $q) {
    }];