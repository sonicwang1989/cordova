var DemoFileCtrl = ['$rootScope', '$scope', '$location', '$window', '$timeout', '$q',
    function ($rootScope, $scope, $location, $window, $timeout, $q) {

    }];

DemoFileCtrl.url = "/demo/file";
DemoFileCtrl.templateUrl = "../html/demo/demofile.html";